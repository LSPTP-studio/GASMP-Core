Thank you for your purchase.
This product has been formally issued under the name Chiaki Haruma. Please review the following conditions carefully:

Purchase Agreement
1.By completing this purchase, you agree to abide by the outlined Terms and Conditions.
2.Redistribution, resale, or claiming authorship of this product is strictly prohibited.
3.As this is a digital item, all sales are considered final. Refunds and cancellations will not be granted.
4.Loss, accidental deletion, or damage to the product after purchase is the sole responsibility of the buyer. We are unable to replace or reissue under such circumstances.
5.These Terms and Conditions may be updated or amended at any time without prior announcement.


Drag/Drop:
ItemsAdder